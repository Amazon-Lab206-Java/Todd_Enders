public class FizzBuzzTest {
    public static void main(String[] args){
        FizzBuzz fb = new FizzBuzz();
        fb.fizzBuzz(5);
        fb.fizzBuzz(3);
        fb.fizzBuzz(15);
        fb.fizzBuzz(6);
        fb.fizzBuzz(7);
    }
}